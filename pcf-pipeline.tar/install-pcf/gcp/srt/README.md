# Small Footprint Runtime on GCP

The `install-pcf/gcp/srt` pipeline deploys Small Footprint Runtime.

**This pipeline is still WIP**. We hope to release this pipeline soon.
