# PCF Fresh Installation Pipelines

### These pipelines are intended to take a properly configured IaaS and lay down a PCF on top
### in accordance with our reference architecture.
#### Please see our reference arch docs on https://docs.pivotal.io/pivotalcf/1-12/refarch/index.html.
